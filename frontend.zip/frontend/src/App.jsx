import { useEffect, useState } from "react";
import PatientDashboard from "./pages/PatientDashboard";
import TriageDashboard from "./pages/TriageDashboard";
import LoginPage from "./pages/LoginPage";
import RecordsPage from "./pages/RecordsPage";
import { fetchCurrentUser, getStoredToken, setAuthToken } from "./services/api";

export default function App() {
  const [patientData, setPatientData] = useState(null);
  const [view, setView] = useState("triage");
  const [auth, setAuth] = useState({ loading: true, user: null });

  useEffect(() => {
    const bootstrapAuth = async () => {
      const token = getStoredToken();
      if (!token) {
        setAuth({ loading: false, user: null });
        return;
      }

      try {
        setAuthToken(token);
        const me = await fetchCurrentUser();
        setAuth({ loading: false, user: me.username });
      } catch {
        setAuthToken(null);
        setAuth({ loading: false, user: null });
      }
    };

    bootstrapAuth();
  }, []);

  const handleLogin = (username, token) => {
    setAuthToken(token);
    setAuth({ loading: false, user: username });
  };

  const handleLogout = () => {
    setAuthToken(null);
    setPatientData(null);
    setView("triage");
    setAuth({ loading: false, user: null });
  };

  if (auth.loading) {
    return (
      <main className="app-shell bg-login">
        <div className="brand-mark">
          <img src="/assets/logo.jpeg" alt="KANINI Logo" className="brand-logo" />
          <div className="brand-text">
            <strong>KANINI Care</strong>
            <span>Smart Triage Platform</span>
          </div>
        </div>
        Loading...
      </main>
    );
  }

  let shellClass = "app-shell";
  if (!auth.user) {
    shellClass += " bg-login";
  } else if (view === "triage" && !patientData) {
    shellClass += " bg-patient";
  } else if (view === "triage" && patientData) {
    shellClass += " bg-triage";
  }

  if (!auth.user) {
    return (
      <main className={shellClass}>
        <div className="brand-mark">
          <img src="/assets/logo.jpeg" alt="KANINI Logo" className="brand-logo" />
          <div className="brand-text">
            <strong>KANINI Care</strong>
            <span>Smart Triage Platform</span>
          </div>
        </div>
        <LoginPage onLogin={handleLogin} />
      </main>
    );
  }

  return (
    <main className={shellClass}>
      <div className="brand-mark">
        <img src="/assets/logo.jpeg" alt="KANINI Logo" className="brand-logo" />
        <div className="brand-text">
          <strong>KANINI Care</strong>
          <span>Smart Triage Platform</span>
        </div>
      </div>
      {view === "records" ? (
        <RecordsPage
          onBack={() => setView("triage")}
          onLogout={handleLogout}
        />
      ) : !patientData ? (
        <PatientDashboard
          onSubmit={setPatientData}
          onViewRecords={() => setView("records")}
        />
      ) : (
        <TriageDashboard
          patientData={patientData}
          onReset={() => setPatientData(null)}
          onLogout={handleLogout}
          onViewRecords={() => setView("records")}
          username={auth.user}
        />
      )}
    </main>
  );
}
