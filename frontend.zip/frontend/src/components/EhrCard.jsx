export default function EhrCard({ ehr }) {
  return (
    <div className="bg-white p-6 rounded-xl shadow-md">
      <h3 className="font-semibold mb-2">EHR Summary</h3>
      <p>Past Visits: {ehr.past_visits}</p>
      <p>Last Risk: {ehr.last_risk}</p>
      <p>Chronic Conditions: {ehr.chronic_conditions}</p>
    </div>
  );
}
