export default function PriorityBar({ score }) {
  return (
    <div className="mb-4">
      <div className="bg-gray-300 rounded-full h-4">
        <div
          className="bg-blue-600 h-4 rounded-full"
          style={{ width: `${score}%` }}
        />
      </div>
      <p className="mt-2">Priority Score: {score}%</p>
    </div>
  );
}
