export default function RiskCard({ data }) {
  const getColor = () => {
    if (data.risk_level === "High") return "bg-red-500";
    if (data.risk_level === "Medium") return "bg-yellow-500";
    return "bg-green-500";
  };

  return (
    <div className={`p-6 rounded-xl text-white ${getColor()} mb-4`}>
      <h2 className="text-xl font-semibold">
        {data.risk_level} Risk
      </h2>
      <p>Department: {data.recommended_department}</p>
      <p>Confidence: {data.confidence}</p>
    </div>
  );
}
