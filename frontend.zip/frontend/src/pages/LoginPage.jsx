import { useState } from "react";
import { loginUser } from "../services/api";

export default function LoginPage({ onLogin }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!username.trim() || !password) {
      setError("Enter username and password.");
      return;
    }

    setLoading(true);
    setError("");

    try {
      const res = await loginUser(username.trim(), password);
      onLogin(res.username, res.access_token);
    } catch {
      setError("Invalid credentials. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="panel login-panel">
      <header className="panel-header">
        <h1>Secure Staff Login</h1>
        <p>Authenticate to access triage workflows and patient records.</p>
      </header>

      <div className="panel-body">
        <div className="form-grid login-grid">
          <div className="field full">
            <label htmlFor="username">Username</label>
            <input
              id="username"
              className="input"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Enter username"
            />
          </div>

          <div className="field full">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              className="input"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter password"
            />
          </div>
        </div>

        <div className="actions">
          <button type="button" className="primary-btn" onClick={handleSubmit} disabled={loading}>
            {loading ? "Signing in..." : "Sign In"}
          </button>
        </div>

        <p className="hint">Default demo credentials: admin / admin123</p>

        {error && <div className="alert error">{error}</div>}
      </div>
    </section>
  );
}
