import { useEffect, useState } from "react";
import { fetchNextPatientId } from "../services/api";

export default function PatientDashboard({ onSubmit, onViewRecords }) {
  const [form, setForm] = useState({
    Patient_ID: "",
    Patient_Name: "",
    Age: "",
    Gender: "Male",
    Symptoms: "",
    Pre_Existing_Conditions: ""
  });
  const [error, setError] = useState("");
  const [loadingId, setLoadingId] = useState(true);

  useEffect(() => {
    const loadNextId = async () => {
      setLoadingId(true);
      try {
        const nextId = await fetchNextPatientId();
        setForm((prev) => ({ ...prev, Patient_ID: nextId }));
      } catch {
        setForm((prev) => ({ ...prev, Patient_ID: 1001 }));
      } finally {
        setLoadingId(false);
      }
    };

    loadNextId();
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = () => {
    const age = Number(form.Age);
    const patientName = form.Patient_Name.trim();
    const symptoms = form.Symptoms
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);

    if (!patientName) {
      setError("Enter patient name.");
      return;
    }

    if (!Number.isFinite(age) || age <= 0) {
      setError("Enter a valid age greater than 0.");
      return;
    }

    if (symptoms.length === 0) {
      setError("Enter at least one symptom.");
      return;
    }

    const conditions = form.Pre_Existing_Conditions
      .split(",")
      .map((c) => c.trim())
      .filter(Boolean);

    setError("");
    onSubmit({
      Patient_ID: Number(form.Patient_ID) || 1001,
      Patient_Name: patientName,
      Age: age,
      Gender: form.Gender,
      Symptoms: symptoms,
      Pre_Existing_Conditions: conditions
    });
  };

  return (
    <section className="panel">
      <header className="panel-header">
        <h1>Smart Triage Intake</h1>
        <p>Capture patient profile details to begin triage evaluation.</p>
      </header>

      <div className="panel-body">
        <div className="form-grid">
          <div className="field">
            <label htmlFor="patientName">Patient Name</label>
            <input
              id="patientName"
              className="input"
              name="Patient_Name"
              placeholder="Enter full name"
              value={form.Patient_Name}
              onChange={handleChange}
            />
          </div>

          <div className="field">
            <label htmlFor="patientId">Patient ID</label>
            <input
              id="patientId"
              className="input"
              name="Patient_ID"
              type="number"
              min="1"
              placeholder="Auto-generated"
              value={form.Patient_ID}
              readOnly
            />
          </div>

          <div className="field">
            <label htmlFor="age">Age</label>
            <input
              id="age"
              className="input"
              name="Age"
              type="number"
              min="1"
              placeholder="Enter age"
              value={form.Age}
              onChange={handleChange}
            />
          </div>

          <div className="field">
            <label htmlFor="gender">Gender</label>
            <select
              id="gender"
              className="input"
              name="Gender"
              value={form.Gender}
              onChange={handleChange}
            >
              <option>Male</option>
              <option>Female</option>
              <option>Other</option>
            </select>
          </div>

          <div className="field full">
            <label htmlFor="symptoms">Symptoms</label>
            <textarea
              id="symptoms"
              className="input"
              name="Symptoms"
              placeholder="Comma separated, e.g. Fever, Chest Pain"
              value={form.Symptoms}
              onChange={handleChange}
            />
          </div>

          <div className="field full">
            <label htmlFor="conditions">Pre-existing Conditions</label>
            <input
              id="conditions"
              className="input"
              name="Pre_Existing_Conditions"
              placeholder="Optional, comma separated"
              value={form.Pre_Existing_Conditions}
              onChange={handleChange}
            />
          </div>
        </div>

        <div className="actions">
          <button
            type="button"
            className="primary-btn"
            onClick={handleSubmit}
            disabled={loadingId || !form.Patient_ID}
          >
            {loadingId ? "Preparing ID..." : "Continue to Vitals"}
          </button>
          <button type="button" className="secondary-btn" onClick={onViewRecords}>
            View Records
          </button>
        </div>

        {error && <div className="alert error">{error}</div>}
      </div>
    </section>
  );
}
