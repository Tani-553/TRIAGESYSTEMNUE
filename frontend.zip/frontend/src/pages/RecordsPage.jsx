import { useEffect, useState } from "react";
import { fetchRecords } from "../services/api";

export default function RecordsPage({ onBack, onLogout }) {
  const [search, setSearch] = useState("");
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const loadRecords = async (query = "") => {
    setLoading(true);
    setError("");

    try {
      const data = await fetchRecords(500, query);
      setRecords(data);
    } catch {
      setError("Unable to load records. Please check your login session.");
      setRecords([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadRecords();
  }, []);

  const handleSearch = () => {
    loadRecords(search.trim());
  };

  return (
    <section className="panel">
      <header className="panel-header">
        <h2>All Patient Records</h2>
        <p>Search by Patient ID or Patient Name.</p>
      </header>

      <div className="panel-body">
        <div className="records-toolbar">
          <input
            className="input"
            placeholder="Search by patient id or name"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <button type="button" className="primary-btn" onClick={handleSearch}>
            Search
          </button>
          <button type="button" className="secondary-btn" onClick={() => loadRecords("")}>
            Clear
          </button>
          <button type="button" className="secondary-btn" onClick={onBack}>
            Back to Triage
          </button>
          <button type="button" className="secondary-btn" onClick={onLogout}>
            Logout
          </button>
        </div>

        {error && <div className="alert error">{error}</div>}

        {loading ? (
          <p className="metric">Loading records...</p>
        ) : records.length === 0 ? (
          <p className="metric">No records found.</p>
        ) : (
          <div className="records-table-wrap">
            <table className="records-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Patient ID</th>
                  <th>Patient Name</th>
                  <th>Age</th>
                  <th>Risk</th>
                  <th>Department</th>
                  <th>HR</th>
                  <th>Temp</th>
                  <th>Timestamp</th>
                </tr>
              </thead>
              <tbody>
                {records.map((record) => (
                  <tr key={record.id}>
                    <td>{record.id}</td>
                    <td>{record.patient_id}</td>
                    <td>{record.patient_name || "-"}</td>
                    <td>{record.age}</td>
                    <td>{record.risk_level}</td>
                    <td>{record.recommended_department}</td>
                    <td>{record.heart_rate}</td>
                    <td>{record.temperature}</td>
                    <td>{record.created_at}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </section>
  );
}
