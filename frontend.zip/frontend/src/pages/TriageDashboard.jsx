import { useEffect, useMemo, useState } from "react";
import { fetchRecords, predictPatient, uploadEhrDataset } from "../services/api";

export default function TriageDashboard({
  patientData,
  onReset,
  onLogout,
  onViewRecords,
  username
}) {
  const [vitals, setVitals] = useState({
    Blood_Pressure: "",
    Heart_Rate: "",
    Temperature: ""
  });
  const [result, setResult] = useState(null);
  const [records, setRecords] = useState([]);
  const [ehrFile, setEhrFile] = useState(null);
  const [ehrUploadInfo, setEhrUploadInfo] = useState("");
  const [uploadedFileName, setUploadedFileName] = useState("");
  const [uploadingEhr, setUploadingEhr] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const riskClass = useMemo(() => {
    if (!result?.risk_level) return "low";
    return result.risk_level.toLowerCase();
  }, [result]);

  const factorSegments = useMemo(() => {
    const entries = Object.entries(result?.top_contributors || {});
    if (entries.length === 0) return [];

    const total = entries.reduce((sum, [, value]) => sum + Number(value || 0), 0) || 1;
    const colors = ["#0f766e", "#0284c7", "#b45309", "#6d28d9", "#b91c1c"];
    let start = 0;

    return entries.map(([name, rawValue], index) => {
      const value = Number(rawValue || 0);
      const percentage = (value / total) * 100;
      const segment = {
        name,
        value,
        percentage,
        color: colors[index % colors.length],
        start,
        end: start + percentage
      };
      start += percentage;
      return segment;
    });
  }, [result]);

  const pieGradient = useMemo(() => {
    if (factorSegments.length === 0) {
      return "conic-gradient(#cbd5e1 0% 100%)";
    }
    const slices = factorSegments
      .map((segment) => `${segment.color} ${segment.start}% ${segment.end}%`)
      .join(", ");
    return `conic-gradient(${slices})`;
  }, [factorSegments]);

  useEffect(() => {
    const loadRecords = async () => {
      try {
        const recent = await fetchRecords(8);
        setRecords(recent);
      } catch {
        setRecords([]);
      }
    };

    loadRecords();
  }, []);

  const handleChange = (e) => {
    setVitals({ ...vitals, [e.target.name]: e.target.value });
  };

  const handleEhrUpload = async () => {
    if (!ehrFile) {
      setEhrUploadInfo("Select a CSV file first.");
      return false;
    }

    setUploadingEhr(true);
    setEhrUploadInfo("");
    try {
      const response = await uploadEhrDataset(ehrFile);
      setUploadedFileName(ehrFile.name);
      setEhrUploadInfo(`Uploaded ${response.rows_loaded} EHR rows from ${ehrFile.name}.`);
      return true;
    } catch (uploadError) {
      const detail = uploadError?.response?.data?.detail;
      setEhrUploadInfo(detail || "EHR upload failed. Check CSV headers and try again.");
      return false;
    } finally {
      setUploadingEhr(false);
    }
  };

  const handleSubmit = async () => {
    const bp = Number(vitals.Blood_Pressure);
    const hr = Number(vitals.Heart_Rate);
    const temp = Number(vitals.Temperature);

    if (!Number.isFinite(bp) || !Number.isFinite(hr) || !Number.isFinite(temp)) {
      setError("Enter valid numeric vitals before submitting.");
      return;
    }

    setLoading(true);
    setError("");

    try {
      if (ehrFile && uploadedFileName !== ehrFile.name) {
        const ok = await handleEhrUpload();
        if (!ok) {
          setLoading(false);
          return;
        }
      }

      const payload = {
        ...patientData,
        Blood_Pressure: bp,
        Heart_Rate: hr,
        Temperature: temp
      };

      const res = await predictPatient(payload);
      setResult(res);

      const recent = await fetchRecords(8);
      setRecords(recent);
    } catch {
      setError("Unable to fetch triage prediction. Check backend status or login session.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="panel">
      <header className="panel-header">
        <h2>Triage Dashboard</h2>
        <p>
          Logged in as <strong>{username}</strong>. Enter current vitals to compute risk and care routing.
        </p>
      </header>

      <div className="panel-body">
        <div className="form-grid">
          <div className="field">
            <label htmlFor="bp">Blood Pressure</label>
            <input
              id="bp"
              className="input"
              name="Blood_Pressure"
              type="number"
              value={vitals.Blood_Pressure}
              onChange={handleChange}
              placeholder="e.g. 120"
            />
          </div>

          <div className="field">
            <label htmlFor="hr">Heart Rate</label>
            <input
              id="hr"
              className="input"
              name="Heart_Rate"
              type="number"
              value={vitals.Heart_Rate}
              onChange={handleChange}
              placeholder="e.g. 85"
            />
          </div>

          <div className="field">
            <label htmlFor="temp">Temperature</label>
            <input
              id="temp"
              className="input"
              name="Temperature"
              type="number"
              step="0.1"
              value={vitals.Temperature}
              onChange={handleChange}
              placeholder="e.g. 99.1"
            />
          </div>

          <div className="field full">
            <label htmlFor="ehrUpload">Upload EHR Dataset (CSV, optional)</label>
            <div className="ehr-upload-row">
              <input
                id="ehrUpload"
                className="input"
                type="file"
                accept=".csv,text/csv"
                onChange={(e) => {
                  const file = e.target.files?.[0] || null;
                  setEhrFile(file);
                  setEhrUploadInfo("");
                }}
              />
              <button
                type="button"
                className="secondary-btn"
                onClick={handleEhrUpload}
                disabled={!ehrFile || uploadingEhr}
              >
                {uploadingEhr ? "Uploading..." : "Upload EHR"}
              </button>
            </div>
            {ehrUploadInfo && <p className="hint">{ehrUploadInfo}</p>}
          </div>
        </div>

        <div className="actions">
          <button
            type="button"
            className="primary-btn"
            onClick={handleSubmit}
            disabled={loading}
          >
            {loading ? "Evaluating..." : "Submit Vitals"}
          </button>
          <button type="button" className="secondary-btn" onClick={onReset}>
            New Patient
          </button>
          <button type="button" className="secondary-btn" onClick={onViewRecords}>
            View Records
          </button>
          <button type="button" className="secondary-btn" onClick={onLogout}>
            Logout
          </button>
        </div>

        {error && <div className="alert error">{error}</div>}

        {result && (
          <div className="results-grid">
            <article className="result-card">
              <h3>Prediction</h3>
              <p className="metric">
                <span className={`badge ${riskClass}`}>{result.risk_level} Risk</span>
              </p>
              <p className="metric">
                <strong>Department:</strong> {result.recommended_department}
              </p>
              <p className="metric">
                <strong>Priority Score:</strong> {result.priority_score}%
              </p>
              <p className="metric">
                <strong>Confidence:</strong> {(result.confidence * 100).toFixed(1)}%
              </p>
              <p className="metric">
                <strong>Recorded At:</strong> {result.recorded_at}
              </p>
            </article>

            <article className="result-card">
              <h3>EHR Summary</h3>
              <p className="metric">
                <strong>Past Visits:</strong> {result.ehr_summary.past_visits}
              </p>
              <p className="metric">
                <strong>Last Risk:</strong> {result.ehr_summary.last_risk}
              </p>
              <p className="metric">
                <strong>Chronic Conditions:</strong> {result.ehr_summary.chronic_conditions}
              </p>
            </article>

            <article className="result-card">
              <h3>Main factors affecting risk assessment</h3>
              <div className="factor-chart-wrap">
                <div className="factor-pie" style={{ background: pieGradient }} />
                <ul className="result-list factor-legend">
                  {factorSegments.map((segment) => (
                    <li key={segment.name}>
                      <span
                        className="legend-dot"
                        style={{ backgroundColor: segment.color }}
                      />
                      <strong>{segment.name}</strong>: {segment.percentage.toFixed(1)}%
                    </li>
                  ))}
                </ul>
              </div>
            </article>

            <article className="result-card record-card-wide">
              <h3>Recent Records</h3>
              {records.length === 0 ? (
                <p className="metric">No records available yet.</p>
              ) : (
                <ul className="result-list">
                  {records.map((record) => (
                    <li key={record.id}>
                      <strong>{record.patient_name || `Patient ${record.patient_id}`}</strong> | {record.risk_level} | HR {record.heart_rate} | Temp {record.temperature} | {record.created_at}
                    </li>
                  ))}
                </ul>
              )}
            </article>
          </div>
        )}
      </div>
    </section>
  );
}
