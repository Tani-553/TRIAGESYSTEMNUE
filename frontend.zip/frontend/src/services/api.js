import axios from "axios";

const API_URL = import.meta.env.VITE_API_URL || "http://127.0.0.1:8000";
const TOKEN_KEY = "triage_auth_token";

const client = axios.create({
  baseURL: API_URL
});

export const setAuthToken = (token) => {
  if (token) {
    client.defaults.headers.common.Authorization = `Bearer ${token}`;
    localStorage.setItem(TOKEN_KEY, token);
    return;
  }

  delete client.defaults.headers.common.Authorization;
  localStorage.removeItem(TOKEN_KEY);
};

export const getStoredToken = () => localStorage.getItem(TOKEN_KEY);

const existingToken = getStoredToken();
if (existingToken) {
  setAuthToken(existingToken);
}

export const loginUser = async (username, password) => {
  const response = await client.post("/auth/login", { username, password });
  return response.data;
};

export const fetchCurrentUser = async () => {
  const response = await client.get("/auth/me");
  return response.data;
};

export const fetchNextPatientId = async () => {
  const response = await client.get("/patients/next-id");
  return response.data.patient_id;
};

export const predictPatient = async (payload) => {
  const response = await client.post("/predict", payload);
  return response.data;
};

export const uploadEhrDataset = async (file) => {
  const form = new FormData();
  form.append("file", file);
  const response = await client.post("/ehr/upload", form, {
    headers: { "Content-Type": "multipart/form-data" }
  });
  return response.data;
};

export const fetchRecords = async (limit = 10, q = "") => {
  const response = await client.get("/records", { params: { limit, q } });
  return response.data.records;
};
